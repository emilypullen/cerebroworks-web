# Central government revenues as a share of GDP - Data package

This data package contains the data that powers the chart ["Central government revenues as a share of GDP"](https://ourworldindata.org/grapher/government-revenues-as-a-share-of-gdp-world-bank?v=1&csvType=full&useColumnShortNames=false) on the Our World in Data website. It was downloaded on May 26, 2025.

### Active Filters

A filtered subset of the full data was downloaded. The following filters were applied:

## CSV Structure

The high level structure of the CSV file is that each row is an observation for an entity (usually a country or region) and a timepoint (usually a year).

The first two columns in the CSV file are "Entity" and "Code". "Entity" is the name of the entity (e.g. "United States"). "Code" is the OWID internal entity code that we use if the entity is a country or region. For normal countries, this is the same as the [iso alpha-3](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) code of the entity (e.g. "USA") - for non-standard countries like historical countries these are custom codes.

The third column is either "Year" or "Day". If the data is annual, this is "Year" and contains only the year as an integer. If the column is "Day", the column contains a date string in the form "YYYY-MM-DD".

The final column is the data column, which is the time series that powers the chart. If the CSV data is downloaded using the "full data" option, then the column corresponds to the time series below. If the CSV data is downloaded using the "only selected data visible in the chart" option then the data column is transformed depending on the chart type and thus the association with the time series might not be as straightforward.

## Metadata.json structure

The .metadata.json file contains metadata about the data package. The "charts" key contains information to recreate the chart, like the title, subtitle etc.. The "columns" key contains information about each of the columns in the csv, like the unit, timespan covered, citation for the data etc..

## About the data

Our World in Data is almost never the original producer of the data - almost all of the data we use has been compiled by others. If you want to re-use data, it is your responsibility to ensure that you adhere to the sources' license and to credit them correctly. Please note that a single time series may have more than one source - e.g. when we stich together data from different time periods by different producers or when we calculate per capita metrics using population data from a second source.

## Detailed information about the data


## Revenue, excluding grants (% of GDP)
Last updated: January 24, 2025  
Next update: January 2026  
Date range: 1972–2023  
Unit: % of GDP  


### How to cite this data

#### In-line citation
If you have limited space (e.g. in data visualizations), you can use this abbreviated in-line citation:  
Data compiled from multiple sources by World Bank (2025) – processed by Our World in Data

#### Full citation
Data compiled from multiple sources by World Bank (2025) – processed by Our World in Data. “Revenue, excluding grants (% of GDP)” [dataset]. Data compiled from multiple sources by World Bank, “World Development Indicators” [original data].
Source: Data compiled from multiple sources by World Bank (2025) – processed by Our World In Data

### How is this data described by its producer - Data compiled from multiple sources by World Bank (2025)?
Revenue is cash receipts from taxes, social contributions, and other revenues such as fines, fees, rent, and income from property or sales. Grants are also considered as revenue but are excluded here.

Limitations and exceptions: For most countries central government finance data have been consolidated into one account, but for others only budgetary central government accounts are available. Countries reporting budgetary data are noted in the country metadata. Because budgetary accounts may not include all central government units (such as social security funds), they usually provide an incomplete picture. In federal states the central government accounts provide an incomplete view of total public finance.

Data on government revenue and expense are collected by the IMF through questionnaires to member countries and by the Organisation for Economic Co-operation and Development (OECD). Despite IMF efforts to standardize data collection, statistics are often incomplete, untimely, and not comparable across countries.

Statistical concept and methodology: The IMF's Government Finance Statistics Manual 2014, harmonized with the 2008 SNA, recommends an accrual accounting method, focusing on all economic events affecting assets, liabilities, revenues, and expenses, not just those represented by cash transactions. It accounts for all changes in stocks, so stock data at the end of an accounting period equal stock data at the beginning of the period plus flows over the period. The 1986 manual considered only debt stocks.

Government finance statistics are reported in local currency. Many countries report government finance data by fiscal year; see country metadata for information on fiscal year end by country.

### Source

#### Data compiled from multiple sources by World Bank – World Development Indicators
Retrieved on: 2025-01-24  
Retrieved from: https://datacatalog.worldbank.org/search/dataset/0037712/World-Development-Indicators  


    